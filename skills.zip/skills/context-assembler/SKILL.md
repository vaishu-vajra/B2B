---
name: context-assembler
description: Assemble a permission-checked, freshness-checked context package for a specified social-content workflow stage. Use before a stage skill runs when it needs only the approved records and inputs relevant to that run.
---

# Context Assembler

## Purpose

Prepare a run-specific context package for one workflow stage. Read the stage contract, check permission before retrieving or selecting records, provide only the current and permitted information the stage needs, and report gaps, conflicts, provisional notes, and a readiness verdict.

This skill assembles context; it does not write or review content, calculate the Knowledge Readiness Score (KRS), approve records, resolve conflicts, modify knowledge files, publish, or change access rights. It contains no client-specific facts. Use the supplied knowledge layer, stage contract, and run inputs.

## Inputs
   
### Required

- Workflow-stage name, run ID, client/project identity, channel, and period where applicable.
- The approved stage contract and policy version. Use the stage requirements below when they are the active workflow contract. If the requested workflow stage or active contract is unclear, do not invent one; report the gap.
- The knowledge index and source files or atomic record register, with source names and versions where available.
- Permission and reuse-scope information for the records and the requesting stage.
- The live inputs required by the stage, such as a period brief, calendar slice, or earlier approved stage output.
- Record metadata needed to check status and freshness: approval status, source, owner, approval date, review date or valid-until date, and applicable refresh window.

### Use when applicable

- current open-feedback information or the current unresolved-feedback list.
- Earlier approved outputs from `output/`.
- Approved market or analytics briefs, event records, assets, and other stage inputs.
- A current readiness assessment, if one exists. Carry its status as context; do not recalculate KRS here.

Do not read conversation archives, restricted records, or evaluation material unless the stage contract and permissions explicitly authorize the relevant source. The evaluation store and answer keys have no runtime read path.

## Workflow-stage requirements

Use this table to select the stage's required information, helpful information, and freshness checks. The descriptions below state what to obtain and check; do not rely on shorthand domain labels as a substitute for these instructions. For period-brief qualification, use the approved competitor list supplied in current project context. A separate Competitor Scan report is optional extra research and is not a required input unless the user requests new competitor or industry research. Apply any newer, formally approved contract supplied for the run and retain its version in the package.

| Workflow stage | Must have (blocks if missing) | Should have (report limitation if missing) | Freshness rule |
|---|---|---|---|
| Readiness and account | LinkedIn company-page identity (URL, stable ID, and company-vs-personal status); current page access, admin and publishing rights; approval chain with approver, backup, client sign-off rules and approval deadlines | Current performance baseline from native LinkedIn data, normally covering the last 90 days | Re-verify page identity and rights this cycle; refresh the baseline within its stated review window |
| Social approach | Approved company positioning and message pillars; project target customer profile and buying roles; audience needs and pains; project objectives and chosen primary KPI with its measurement definition | Current performance baseline; recent industry and competitor intelligence | Target customer profile no older than 6 months |
| Period brief and intelligence | Period objectives and one selected primary KPI with its measurement definition | Approved competitor set | New industry or competitor research is not required for this pilot. Sourced audience-language research and performance breakdowns by theme or format are waived for this pilot and must not lower readiness.
| Calendar and item briefs | Qualified period brief; approved content pillars; project scope (cadence, formats, languages, exclusions); confirmed events and calendar dates | Subject-matter expert topics, availability and review turnaround; relevant events in the planning month | Use confirmed dates for the planning month; flag unconfirmed dates |
| Copy and claims | Approved brand positioning, voice, writing rules and client-selected approved post samples; claims register with permitted wording, evidence and reuse permissions; selected item brief | Audience language with sources; approved long-form content such as blogs, white papers or webinars | Claims must be unexpired |
| Assets | Approved brand guidelines; assets whose usage rights are recorded; current platform specifications | None specified | Platform specifications no older than 90 days |
| Quality review | Claims register, evidence and named-client permissions; approved brand voice and writing rules; quality rubric | Applicable disclosure policy | Apply each source's review window; claims must be unexpired and platform specifications no older than 90 days |
| Approval and publishing | Approval chain; verified LinkedIn page access and publishing rights; CTA destinations and tracking-link rules | None specified | Re-verify page rights and approval chain at release |
| Community management | Current response and escalation playbook with contacts; approved company facts | Audience objections | Response playbook must be current |
| Measurement | Metric definitions and current performance baseline; native LinkedIn analytics export from this cycle | Past performance reports | Use an analytics export from the current cycle |
| Review and improvement | Current-cycle measurement report; feedback and rework log | Current industry or market change brief | Use the report and feedback from this cycle |

If a stage contract supplied for the run differs from this table, follow the formally approved version and report the version used. Do not turn a “should have” item into a required item unless the active contract says so.

## Workflow

1. **Identify the run and stage.** Confirm the run ID, stage, client/project, channel, period, and policy/contract version. If any identifier is missing and affects record selection, request it rather than guessing.
2. **Read the stage contract.** List the required items, helpful items, and freshness windows for this stage. Do not assemble a general client dossier.
3. **Check permission first.** Before reading or selecting each source, confirm that its client/project scope and reuse permission allow this stage to access it. Do not retrieve restricted content when permission is absent or unclear. If access is disallowed or cannot be confirmed, withhold the content and report the source description only as permitted.
4. **Select the minimum relevant material.** Include only approved knowledge records, the live task inputs, and earlier approved stage outputs needed by the contract. Identify source and record names with their versions when those details are supplied; do not invent identifiers. Do not expose unrelated records or raw conversation transcripts.
5. **Check status and freshness.** Confirm that each selected record is approved and current for its stated refresh window. A missing review date, missing approval status, or unknown freshness is not proof that a record is current. Treat an expired or unapproved record as unavailable for factual use; report it as a gap. Apply the stage-specific freshness rules above.
6. **Detect conflicts and provisional information.** Compare relevant records and inputs. Keep conflicting records identified as disputed; never choose one merely because it is newer. Label hypotheses, observations, pending decisions, and other provisional notes clearly as not approved facts or public claims. If a pending decision could change scope, claims, or approvals, mark the package Limited until it is confirmed in writing.
7. **Assess gaps.** For every missing, stale, restricted, or conflicting item, state the requirement, source descriptions and versions involved, known owner, impact, and whether it blocks. Use “Owner not specified” if no owner is identified. Do not invent owners, permissions, approvals, or source data.
8. **Set the stage verdict.**
   - **READY:** All required inputs are present, approved, permitted, current, and non-conflicting; no material limitation remains.
   - **LIMITED:** Required inputs are available, but one or more helpful inputs or other non-blocking items are missing, stale, disputed, or provisional. State the limits and what the stage may safely proceed with.
   - **BLOCKED:** A required input is missing, expired, unapproved, inaccessible, or materially conflicting, so the stage cannot safely proceed.
   Never raise a supplied readiness status. A stage-level verdict is not the KRS and does not approve the knowledge layer.
9. **Build the context package.** Return the output format below. Include only permitted excerpts or wording needed by the stage; preserve descriptive source names and versions for traceability.

## Context package output

Save one context package per workflow stage in the project’s `context package/` folder. Name each file `context_assembler_<MM>_<DD>_<version>_<stage_name>.md`, for example `context_assembler_11_11_01_brand_qa.md`. Use a readable lowercase stage name with underscores, not a stage code. Start with version `01` for each stage name and increment it for additional runs of that stage on the same date. When file creation is not available, return this structure in the conversation. Use `Not provided`, `Not verified`, or `Not applicable` rather than leaving ambiguous blanks.

```markdown
# Run Context Package

## Run header
- Client:
- Project:
- Channel:
- Period:
- Run ID:
- Stage:
- Stage-contract version:
- Policy version:
- Assembled on:

## Stage contract
- Required inputs:
- Helpful inputs:
- Freshness rules:

## Selected sources and information
| Source or record name | Version | Information needed by the stage | Status | Permission/scope | Freshness check | Permitted wording or relevant excerpt |
|---|---|---|---|---|---|---|

## Run inputs and prior approved outputs
| Input/output | Version or date | Source | Stage relevance |
|---|---|---|---|

## Provisional notes
| Note | Source and version | Why provisional | Not-for-claims reminder |
|---|---|---|---|

## Gaps and conflicts
| Missing/disputed item | Sources/records involved | Owner | Blocking? | What is needed |
|---|---|---|---|---|

## Verdict
- Result: READY / LIMITED / BLOCKED
- Reason:
- Permitted next action:
- Limitations:

## Run record
- Records and versions checked:
- Sources withheld due to permission/status:
- Escalations or questions:
```

For a BLOCKED package, identify the blockers and owners and state that the downstream stage must not proceed. Do not include unapproved content in the selected-sources section. For a LIMITED package, identify what may proceed and keep each limitation attached to the relevant record or input.

## Boundaries

- The context package is not a new approval record. Only an authorized human can approve a knowledge record or deliverable.
- Do not write proposed fixes into the knowledge layer. Report them for the responsible owner.
- Do not treat public availability as reuse permission for a client name, logo, result, or asset.
- Do not silently reconcile conflicting sources or turn provisional notes into facts.
- Do not calculate or infer a KRS from incomplete metadata. If a readiness score is supplied, report its source and version without changing it.
- Do not expose restricted personal information or evaluation answers in a context package.

## Run artifact storage
All context packages belong in the project’s `context package/` folder, one per workflow stage. Use the descriptive stage name in the filename; do not use internal stage codes. Do not save context packages in `output/`.
---
name: brand-qa-reviewer
description: Review text-only LinkedIn post copy against approved company facts, permissions, brand guidance, and the quality rubric. Use when the user wants a review and issue report, not drafting, approval, or publishing.
---

# Brand QA Reviewer

## Purpose

Review a submitted LinkedIn post package against the supplied brief and approved knowledge. Identify factual, permission, brand, and quality issues; explain where each issue occurs and what should change. Return a review report for a human to resolve.

This skill reviews only the materials supplied for the run. It does not create a calendar, rewrite the full post unless specifically asked for suggested corrections, approve content, or publish to LinkedIn. It contains no client-specific facts; obtain them from the supplied brief and approved context.

## Required knowledge and context

Use descriptive names for the approved guidance and records supplied in the context package. Do not rely on fixed section codes or hard-coded client paths.

**Must have:**

- Approved voice and tone guidance.
- Approved writing rules and restrictions.
- Approved claim wording, evidence, and reuse permissions.
- Target audience definition relevant to the post.
- Applicable quality rubric.
- The period brief and the selected item brief or calendar row.

The context package should identify selected records and versions, permission/freshness checks, gaps, conflicts, and its Ready/Limited/Blocked verdict. For a pilot run without an assembler, use the supplied current approved knowledge material to locate relevant guidance, then check their status, permissions, and review dates before applying the same verdict rules. Do not treat a missing context package as an error in that pilot mode when the index and necessary records are supplied.

If required guidance or the submission itself is missing, do not invent a rule or assume the missing material passes. Report what is missing and whether review is blocked or limited.

## Inputs

### Required

- Client, project, and LinkedIn channel identity.
- The exact post copy submitted for review.
- The period brief and selected item brief or calendar row (or IDs with access to them).
- A context package with its verdict; or, in pilot mode without an assembler, the knowledge index and relevant approved knowledge material.

### Helpful

- This pilot is text-only. Images, carousel slides, videos, captions, alt text, and other creative materials are outside the review scope and are not required.
- Claim descriptions or evidence references already attached to the draft.
- Reviewer notes, requested changes, and the previous QA report if this is a revision.
- The draft copy and the versions of the brief and knowledge records used.
- Claim-specific disclaimers required by approved claim records and other supplied channel-specific requirements.

Review only the submitted LinkedIn post copy. Do not request or assess images, carousel slides, videos, captions, alt text, or other creative materials.

### Current pilot scope

For this pilot, compare the submitted post text with available LinkedIn post copy in learning.md for close repetition or overlap. Do not review creative assets. Treat Created dates as record dates, not Published dates; do not describe a post as recently published based on Created date alone. If text coverage or a reliable match is incomplete, state the scope of the comparison or mark it partially assessed. This limitation alone does not require REVISE or BLOCKED. Treat historical feedback records as evidence of comments or corrections, not as formal rules unless an approval is recorded.
For this text-only Vajra pilot, check LinkedIn post copy against these writing standards: body of 60–150 words, short paragraphs, one core idea, one CTA, no more than three hashtags from the approved pilot bank, and no more than 3,000 characters total. Do not require an AI-content-disclosure policy or flag its absence for this pilot. Continue checking claim-specific disclaimers when an approved claim record requires them.

## Workflow

1. **Check the available review evidence before reviewing.** Record the supplied context verdict and any Post Writer drafting-readiness verdict separately as upstream metadata. Do not inherit either verdict as the Brand QA result or downgrade the QA result solely because an earlier stage reported Limited. Independently verify whether the source records, permissions, brief, and context needed for this review are actually present and usable. If an identified limitation prevents a required QA check, assess only what can be checked and reflect that limitation in the QA result; if required evidence is available and the limitation is unrelated to this draft, continue without carrying it forward. In pilot mode, derive any context verdict from required sections' status, permission, and freshness information.
2. **Confirm the review scope.** Record the post/item identifier, copy version, and brief/context versions where provided. Compare the submitted text with the selected calendar row and item brief: objective, audience, message/angle, CTA, format, and slot. Report deviations; do not silently change the brief.
3. **Check factual claims and permissions.** Identify each factual claim about the company, its services, clients, results, people, credentials, awards, partners, products, or guarantees. Match it to an approved claim record and permitted wording, evidence, reuse permission, and disclosure requirements. Flag claims that are missing, overstated, outdated, outside permission scope, or in conflict. Do not treat a public website page as approval to reuse its claims unless the supplied approved record permits that use.
4. **Check brand and audience fit.** Compare the copy with approved voice, writing, and audience guidance. Check clarity, tone, relevance, CTA, and accessibility requirements only where the relevant guidance or rubric defines them. Do not invent brand rules.
5. **Score against the supplied quality rubric.** Use the supplied rubric and its scoring anchors. Report each applicable dimension, score, and rationale. If the rubric is missing or lacks an anchor for a dimension, mark it Not assessed; do not create replacement thresholds.
6. **Record findings.** For every issue, identify its severity, exact location, applicable rule or source description/version, reason, and recommended action. Suggested replacement wording may be provided for clarity, but must not introduce new factual claims or alter the approved message without support.
7. **Set the QA result.** Use one of these outcomes; they are result labels, not steps in a sequence:
   - **PASS:** All required checks were assessable and no unresolved critical or material issues remain.
   - **REVISE:** The post copy contains fixable issues, or a non-blocking limitation prevents a complete QA result. State what needs changing.
   - **BLOCKED:** A required source, permission, brief, or context check is missing or conflicting, so a reliable review cannot be completed.
   Do not set PASS, REVISE, or BLOCKED solely from the context or Post Writer verdict. Use REVISE when an actual copy issue or a relevant non-blocking gap remains; use BLOCKED when an actual required check cannot be completed reliably. A context verdict of Limited can coexist with PASS when its stated limitation is unrelated to this draft and all required QA checks are assessable. An incomplete or partially assessed post-copy comparison by itself does not cause REVISE or BLOCKED.
8. **Record the QA decision separately.** Report the QA result and whether any critical findings remain. The user records the content decision; do not infer or change that decision from the QA result.
9. **Keep evaluation material out of ordinary review.** Do not load or reveal evaluation answer keys, seeded test cases, or expected answers during a normal content review. Store evaluation outputs separately when an explicitly authorized evaluation process is run.

## Review rules

- Judge claims only against the approved records and permissions supplied for this run. Do not infer permission from a public URL, a logo appearing online, or the mere existence of a case study.
- Do not resolve conflicting records by choosing the newest one. Surface the conflict and block the affected check if needed.
- Treat provisional, unapproved, expired, or restricted records according to their stated status and scope; never present them as approved facts.
- Check the submitted post copy only. Visual assets and any text embedded in them are outside this pilot scope. Do not request or claim to have assessed them.
- Do not infer that LinkedIn account permissions have been granted or changed. This skill does not manage access or publish content.
- Keep findings specific and actionable. Separate critical issues that prevent safe use from lower-severity improvements, using the rubric's definitions when supplied.
- Do not infer or alter a human review or approval decision; report the QA result separately.

## Output format

Return this Markdown structure. Use `Not provided`, `Not assessed`, or `Not verified` where appropriate; do not leave blanks that could be mistaken for confirmation.

```markdown
# LinkedIn Brand and Content QA Review

## Item reviewed
- Client/project/channel:
- Calendar item or brief ID:
- Copy/version reviewed:
- Review scope: Text-only post copy; creative materials are outside scope.
- Post Writer drafting-readiness verdict: READY / LIMITED / BLOCKED / NOT PROVIDED
- Brief/context/knowledge versions:

## QA result
- Result: PASS / REVISE / BLOCKED
- Context verdict: READY / LIMITED / BLOCKED
- Treat upstream context and Post Writer verdicts as metadata; assess Brand QA independently.
- Summary:

## Findings
| Severity | Location | Rule or knowledge record (ID/version) | Issue and reason | Recommended action |
|---|---|---|---|---|

## Claim and permission check
| Claim or text element | Approved source and permission | Result | Notes |
|---|---|---|---|

## Quality scores
| Rubric dimension | Score | Rationale |
|---|---:|---|

## Suggested corrections
- ...

## Review completion
- Required copy and claim checks completed: Yes / No / Not assessed
- Critical findings remaining:
- Sources and versions checked:

## Questions or limitations
- ...
```

If the verdict is BLOCKED, return the blockers, supplied owners, and questions; do not report unsupported pass/fail judgments for unchecked content. If the verdict is LIMITED, clearly identify which sections were reviewed and which could not be assessed.

## Run artifact storage
Save the final QA report and run record in the project’s `output/` folder. Name the file `<skill_name>_<MM>_<DD>_<version>.md`, for example `brand_qa_reviewer_11_11_01.md`. Start with version `01` and increment it for each additional run of this skill on the same date.
